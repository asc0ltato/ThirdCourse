<?php

namespace Drupal\calcfielder\Plugin\Field\FieldType;

use Drupal\Core\Field\FieldItemBase;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\TypedData\DataDefinition;

/**
 * Plugin implementation of the 'calc_field' field type.
 *
 * @FieldType(
 *   id = "calc_field",
 *   label = @Translation("Calculated Field"),
 *   description = @Translation("A field that computes its value based on other fields."),
 *   default_widget = "string_textfield",
 *   default_formatter = "string"
 * )
 */
class CalcField extends FieldItemBase {

  /**
   * Define the database schema for the field.
   */
  public static function schema(FieldStorageDefinitionInterface $field_storage_definition) {
    return [
      'columns' => [
        'value' => [
          'type' => 'varchar',
          'length' => 255,
        ],
      ],
    ];
  }

  /**
   * Define the field properties.
   */
  public static function propertyDefinitions(FieldStorageDefinitionInterface $field_storage_definition) {
    $properties['value'] = DataDefinition::create('string')
      ->setLabel(t('Value'))
      ->setDescription(t('The calculated value.'));
    return $properties;
  }

  /**
   * Automatically compute the value before saving the entity.
   */
  public function preSave() {
    $entity = $this->getEntity();

    // Replace `field_1` and `field_2` with the actual field machine names.
    $field_1 = $entity->get('field_1')->value ?? 0;
    $field_2 = $entity->get('field_2')->value ?? 0;

    // Perform calculation.
    $this->set('value', $field_1 + $field_2);
  }
}
