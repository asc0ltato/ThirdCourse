DROP TABLE IF EXISTS `#__osmeta_metadata`;
