<?php

namespace Cleantalk\Common\Firewall\Exceptions;

class SfwUpdateExit extends \Exception
{
}
