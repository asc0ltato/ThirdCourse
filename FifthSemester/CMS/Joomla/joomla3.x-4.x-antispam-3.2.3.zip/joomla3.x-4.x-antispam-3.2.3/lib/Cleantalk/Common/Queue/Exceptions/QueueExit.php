<?php

namespace Cleantalk\Common\Queue\Exceptions;

class QueueExit extends \Exception
{
}
