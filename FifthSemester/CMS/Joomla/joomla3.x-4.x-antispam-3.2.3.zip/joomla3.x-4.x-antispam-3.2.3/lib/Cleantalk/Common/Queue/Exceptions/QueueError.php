<?php

namespace Cleantalk\Common\Queue\Exceptions;

class QueueError extends \Exception
{
}
