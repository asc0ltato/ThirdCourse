<?php

namespace Cleantalk\Common\RemoteCalls\Exceptions;

class RemoteCallsException extends \Exception
{
}
