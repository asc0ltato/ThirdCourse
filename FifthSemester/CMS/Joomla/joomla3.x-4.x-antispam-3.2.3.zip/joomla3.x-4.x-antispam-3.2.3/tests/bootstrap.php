<?php
require_once dirname( dirname( __FILE__ ) ) . '/lib/autoload.php';