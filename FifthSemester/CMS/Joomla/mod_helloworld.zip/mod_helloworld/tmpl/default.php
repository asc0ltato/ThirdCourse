<style>
    #contact-form-container {
        text-align: center;
    }

    #contact-form {
        display: none;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        margin: 20px auto;
        text-align: left;
    }

    #contact-button {
        cursor: pointer;
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        margin: 0 auto;
        display: inline-block;
    }

    #contact-form label {
        font-weight: bold;
        display: block;
        margin-top: 10px;
    }

    #contact-form input, #contact-form textarea {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    #contact-submit {
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        cursor: pointer;
        margin-top: 20px;
    }

    .message {
        font-size: 14px;
        margin-top: 10px;
    }

    .error {
        color: red;
    }

    .success {
        color: green;
    }
</style>

<div id="contact-form-container">
    <button id="contact-button">Contact Us</button>

    <div id="contact-form">
        <form id="contactForm">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" required>

            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>

            <div id="captcha-container">
                <label>Captcha: <span id="captcha-question"><?= $captcha['num1'] ?> + <?= $captcha['num2'] ?></span> = </label>
                <input type="text" id="captcha" required>
                <input type="hidden" id="correct-sum" value="<?= $captcha['sum'] ?>">
            </div>

            <button type="button" id="contact-submit">Send</button>
        </form>

        <p id="form-message" class="message"></p>
    </div>
</div>

<script>
    document.getElementById('contact-button').onclick = function() {
        var form = document.getElementById('contact-form');
        form.style.display = form.style.display === 'none' ? 'block' : 'none';
    }

    document.getElementById('contact-submit').onclick = function() {
        var name = document.getElementById('name').value.trim();
        var subject = document.getElementById('subject').value.trim();
        var message = document.getElementById('message').value.trim();
        var captcha = document.getElementById('captcha').value.trim();
        var correctSum = document.getElementById('correct-sum').value;
        var messageContainer = document.getElementById('form-message');

        if (!name || !subject || !message) {
            messageContainer.textContent = "Пожалуйста, заполните все поля.";
            messageContainer.className = "message error";
            return;
        }

        if (captcha !== correctSum) {
            messageContainer.textContent = "Неверная капча. Пожалуйста, попробуйте снова.";
            messageContainer.className = "message error";
            return;
        }

        messageContainer.textContent = "Сообщение успешно отправлено!";
        messageContainer.className = "message success";

        document.getElementById('contactForm').reset();
    }
</script>