#pragma once

//  Gloabl variables that help implement IClassFactory.
extern LONG g_cRefDll;
extern LONG g_cServerLocks;