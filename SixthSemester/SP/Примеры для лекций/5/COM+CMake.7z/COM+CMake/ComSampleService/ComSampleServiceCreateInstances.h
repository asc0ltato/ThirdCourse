#pragma once

//  Creation function for CComServerTest.
HRESULT CComServiceTest_CreateInstance(__in REFIID riid, __deref_out void **ppv);
